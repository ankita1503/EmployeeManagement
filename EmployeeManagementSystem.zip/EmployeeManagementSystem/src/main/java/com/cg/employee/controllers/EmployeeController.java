package com.cg.employee.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;
import com.cg.employee.services.EmployeeServices;


@RestController
@RequestMapping(value = "/employee")
public class EmployeeController 
{
	@Autowired
    EmployeeServices employeeServices;
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ResponseEntity<String> getAcceptEmployeeDetails(@ModelAttribute Employee employee)
	{
		employee = employeeServices.acceptEmployeeDetails(employee);
		return new ResponseEntity<String>("Employee Details Accepted Successfully!\n" + employee,HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/list/{empId}"}, method=RequestMethod.GET)
	public ResponseEntity<Employee> getEmployeeDetails(@PathVariable(value="empId") Integer empId, @ModelAttribute Employee employee) throws EmployeeDetailsNotFoundException
	{
		employee = employeeServices.getEmployeeDetails(empId);
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/list"},method=RequestMethod.GET)
	public ResponseEntity<List<Employee>> getAllEmployeeDetailsPathParam()
	{
		return new ResponseEntity<List<Employee>>(employeeServices.getAllEmployeeDetails(),HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/delete/{empId}"},method=RequestMethod.DELETE)
	public ResponseEntity<String> getDeleteEmployeeDetailsPathParam(@PathVariable(value="empId") Integer empId, @ModelAttribute Employee employee) throws EmployeeDetailsNotFoundException
	{
		boolean status = employeeServices.deleteEmployeeDetails(empId);
		return new ResponseEntity<String>("Employee Details Deleted Successfully",HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/update/{empId}"},method=RequestMethod.DELETE)
	public ResponseEntity<Employee> getUpdateEmployeeDetailsPathParam(@PathVariable(value="empId") Integer empId, @ModelAttribute Employee employee) throws EmployeeDetailsNotFoundException
	{
		employee = employeeServices.updateEmployeeDetails(empId);
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	
}
